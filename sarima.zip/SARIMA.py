
# coding: utf-8

# In[24]:

import pandas as pd
import numpy as np
import matplotlib.pylab as plt
from statsmodels.tsa.statespace.sarimax import SARIMAX


# In[62]:

#loading air passengers data
dateparse = lambda dates: pd.datetime.strptime(dates, '%Y-%m')
data = pd.read_csv('D:/AV/timeseries/sarima/AirPassengers.csv', parse_dates=['Month'], index_col='Month', date_parser=dateparse)
series = data['#Passengers']


# In[35]:

#series = pd.to_numeric(series, errors='coerce')
#series.head()


# In[63]:

#visualize the data
plt.plot(series);
plt.title ("Time Series Data");
plt.xlabel('Year');
plt.ylabel('Passengers');


# In[38]:

#training percentage
percent_training = 0.70
split_point = round(len(series)*percent_training)
training, testing = series[0:split_point], series[split_point:]


# In[40]:

#Since data has multiplicative, apply log transorm
training = np.log(training)


# In[41]:

#Since +ve linear trend, apply differencing of 1 period
training_diff = training.diff(periods=1).values[1:]


# In[42]:

#residual plot
plt.plot(training_diff)
plt.title('Time series data')
plt.xlabel('Year')
plt.ylabel('Passengers')


# In[45]:

#getting acf/pcf
from statsmodels.tsa.stattools import acf, pacf
lag_acf = acf(training_diff, nlags = 40)
lag_pacf = pacf(training_diff, nlags = 40, method = 'ols')


# In[48]:

#plot acf
plt.figure(figsize=(15,5))
plt.subplot(121)
plt.stem(lag_acf)
plt.axhline(y = 0, linestyle = '-', color = 'black')
plt.axhline(y = 1.96/np.sqrt(len(training)), linestyle = '--', color = 'gray')
plt.axhline(y = 1.96/np.sqrt(len(training)), linestyle = '--', color = 'gray')
plt.xlabel('Lag')
plt.ylabel('ACF')

#plot pacf
plt.subplot(122)
plt.stem(lag_pacf)
plt.axhline(y = 0, linestyle = '-', color = 'black')
plt.axhline(y = 1.96/np.sqrt(len(training)), linestyle = '--', color = 'gray')
plt.axhline(y = 1.96/np.sqrt(len(training)), linestyle = '--', color = 'gray')
plt.xlabel('Lag')
plt.ylabel('ACF')
plt.tight_layout()


# In[49]:

#Looking at the ACF and PACF plots of the differenced series 
#we see our first significant value at lag 4 for ACF and at the same lag 4 for the PACF 
#which suggest to use p = 4 and q = 4. 
#We also have a big value at lag 12 in the ACF plot which suggests our season is S = 12 
#and since this lag is positive it suggests P = 1 and Q = 0. 
#Since this is a differenced series for SARIMA we set d = 1, 
#and since the seasonal pattern is not stable over time we set D = 0. 
#All together this gives us a SARIMA(4,1,4)(1,0,0)[12] model. 
#Next we run SARIMA with these values to fit a model on our training data.


# In[53]:

#input is training, if training_diff then d = 0
model = SARIMAX(training, order = (4,1,4), seasonal_order=(1,0,0,12), enforce_stationarity=False, enforce_invertibility=False)
model_fit = model.fit(disp=False)


# In[54]:

#Forecasting
K = len(testing) #no of future time steps we want to forecast
forecast = model_fit.forecast(K)
forecast = np.exp(forecast) #transforming back to non-log scale


# In[57]:

plt.figure(figsize=(15,5))
plt.plot(forecast, 'r')
plt.plot(series, 'b')
plt.title('RMSE: %.2f'% np.sqrt(sum((forecast - testing)*2)/len(testing)))
plt.xlabel('Years')
plt.ylabel('Passengers')
plt.autoscale(enable=True, axis='x', tight=True)
plt.axvline(x = series.index[split_point], color = 'black') #line to divide training and testing data


# In[55]:

np.sqrt(sum((forecast - testing)*2)/len(testing))


# In[ ]:



